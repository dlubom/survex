/ pos=dump warn=1 dummycrprotection=
@1314000.0,5428000.0,50.0,-60,0.0;
$-60;
&WGS 1984;
/ *fix bh reference 174.7767 -41.2784 30
#backread.dat,
C1[m,1313799.91,5427953.18,30];
