/* filelist.h
 * Filename extensions used by Survex programs
 * Copyright (C) 1993-2001 Olly Betts
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see
 * <https://www.gnu.org/licenses/>.
 */

#define EXT_SVX_DATA "svx"
#define EXT_SVX_3D   "3d"
#define EXT_SVX_ERRS "err"
#define EXT_SVX_POS  "pos"
#define EXT_SVX_MSG  "msg"
#define EXT_INI      "ini"
#define EXT_LOG      "log"
